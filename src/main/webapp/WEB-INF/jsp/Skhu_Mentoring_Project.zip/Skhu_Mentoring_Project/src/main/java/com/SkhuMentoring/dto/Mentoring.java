package com.SkhuMentoring.dto;

import lombok.Data;

import java.util.Date;

@Data
public class Mentoring {
    private int mno;
    private String userId;
    private String student1;
    private String student2;
    private String student3;
    private String student4;
    private String student5;
    private String student6;
    private String student7;
    private String student8;

}
