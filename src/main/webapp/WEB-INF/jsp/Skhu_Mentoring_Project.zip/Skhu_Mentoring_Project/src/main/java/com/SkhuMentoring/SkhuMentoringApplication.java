package com.SkhuMentoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkhuMentoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkhuMentoringApplication.class, args);
	}

}
