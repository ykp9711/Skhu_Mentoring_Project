package com.SkhuMentoring.dto;

import lombok.Data;

@Data
public class Department {
    private int dno;
    private String department;
}
