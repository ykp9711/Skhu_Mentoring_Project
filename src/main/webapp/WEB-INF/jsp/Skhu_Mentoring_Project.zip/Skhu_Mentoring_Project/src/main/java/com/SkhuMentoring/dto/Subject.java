package com.SkhuMentoring.dto;

import lombok.Data;

@Data
public class Subject {
    private Long sno;
    private String subjectName;
}
